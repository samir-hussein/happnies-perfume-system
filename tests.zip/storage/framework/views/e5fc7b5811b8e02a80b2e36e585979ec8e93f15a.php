<?php $__env->startSection('title', 'تسجيل الدخول'); ?>

<?php $__env->startSection('content'); ?>
    <form class="col-lg-6 col-md-8 col-10 mx-auto" action="<?php echo e(route('login.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="role" value="admin">
        <div class="mx-auto text-center my-4">
            <a class="navbar-brand mx-auto mt-2 flex-fill text-center" href="/">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" width="100">
            </a>
            <h2 class="my-3">تسجيل الدخول</h2>

            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

        </div>
        <div class="form-group">
            <label for="inputEmail4">البريد الإلكترونى</label>
            <input dir="auto" type="email" class="form-control" name="email" id="inputEmail4"
                value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red">* <?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="row mb-4">
            <div class="col-12">
                <div class="form-group">
                    <label for="inputPassword5">كلمة المرور</label>
                    <input dir="auto" type="password" class="form-control" name="password" id="inputPassword5">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red">* <?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">تسجيل الدخول</button>

        <p class="mt-5 mb-3 text-muted text-center" dir="ltr">2024 © <a href="https://www.facebook.com/samirHussein011"
                target="_blank">Samir Hussein</a></p>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\desktop-apps\test\resources\views/login.blade.php ENDPATH**/ ?>