<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'الاقسام'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row align-items-center my-3">
                    <div class="col">
                        <h2 class="page-title">اضافة قسم</h2>
                    </div>
                </div>
                <form action="<?php echo e(route('dashboard.category.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="text" name="name" class="form-control" placeholder="اسم القسم">
                        <select name="type" class="form-control" id="">
                            <option value="product">منتج</option>
                            <option value="material">خامات</option>
                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">اضافة</button>
                        </div>
                    </div>
                </form>
                <div class="row align-items-center my-3">
                    <div class="col">
                        <h2 class="page-title">الاقسام</h2>
                    </div>
                </div>
                <div class="row my-4">
                    <!-- Small table -->
                    <div class="col-md-12">
                        <div class="card shadow">
                            <div class="card-body">
                                <!-- table -->
                                <table class="table datatables" id="dataTable-1">
                                    <thead>
                                        <tr>
                                            <th>الاسم</th>
                                            <th>النوع</th>
                                            <th>عدد المنتجات</th>
                                            <th>حذف</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <span><?php echo e($category->name); ?></span>
                                                    <div class="card-body">
                                                        <form id="category_<?php echo e($category->id); ?>" class="form-inline"
                                                            method="POST"
                                                            action="<?php echo e(route('dashboard.category.update', ['category' => $category->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <input name="name" type="text"
                                                                class="form-control mb-2 mr-sm-2" placeholder="اسم المجموعة"
                                                                value="<?php echo e($category->name); ?>">
                                                            <button for="category_<?php echo e($category->id); ?>" type="submit"
                                                                class="btn btn-sm btn-warning mb-2">تعديل</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="card-body">
                                                        <form id="category_type_<?php echo e($category->id); ?>" class="form-inline"
                                                            method="POST"
                                                            action="<?php echo e(route('dashboard.category.update', ['category' => $category->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <select name="type" class="form-control" id="">
                                                                <option
                                                                    <?php echo e($category->type == 'product' ? 'selected' : ''); ?>

                                                                    value="product">منتج</option>
                                                                <option
                                                                    <?php echo e($category->type == 'material' ? 'selected' : ''); ?>

                                                                    value="material">خامات</option>
                                                            </select>
                                                            <button for="category_type_<?php echo e($category->id); ?>" type="submit"
                                                                class="btn btn-sm btn-warning mb-2">تعديل</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <td><?php echo e($category->products->count('id')); ?></td>
                                                <td>
                                                    <form method="post"
                                                        action="<?php echo e(route('dashboard.category.destroy', ['category' => $category->id])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit"
                                                            class="btn btn-sm btn-danger mb-2">حذف</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> <!-- simple table -->
                </div> <!-- end section -->
            </div> <!-- .col-12 -->
        </div> <!-- .row -->
    </div> <!-- .container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src='<?php echo e(asset('dashboard/js/jquery.dataTables.min.js')); ?>'></script>
    <script src='<?php echo e(asset('dashboard/js/dataTables.bootstrap4.min.js')); ?>'></script>

    <script>
        $('#dataTable-1').DataTable({
            autoWidth: true,
            order: []
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\desktop-apps\test\resources\views/dashboard/category/index.blade.php ENDPATH**/ ?>