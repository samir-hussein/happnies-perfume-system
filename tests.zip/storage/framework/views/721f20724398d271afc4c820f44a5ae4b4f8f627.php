<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'الموظفيين'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php $__errorArgs = ['work_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php $__errorArgs = ['work_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="row col-12">
                <div class="col-md-6 col-xl-6 mb-4">
                    <div class="card shadow mb-4">
                        <div class="card-header">
                            <span class="card-title">عدد الموظفيين</span>
                        </div>
                        <div class="card-body my-n1">
                            <div class="d-flex">
                                <div class="flex-fill">
                                    <h4 class="mb-0"><?php echo e(count($employees)); ?></h4>
                                </div>
                                <div class="flex-fill text-right">
                                    <span class="sparkline inlinebar"><canvas width="40" height="32"
                                            style="display: inline-block; width: 40px; height: 32px; vertical-align: top;"></canvas></span>
                                </div>
                            </div>
                        </div> <!-- .card-body -->
                    </div> <!-- .card -->
                </div>
                <div class="col-md-6 col-xl-6 mb-4">
                    <div class="card shadow mb-4">
                        <div class="card-header">
                            <span class="card-title">اجمالى الرواتب</span>
                        </div>
                        <div class="card-body my-n1">
                            <div class="d-flex">
                                <div class="flex-fill">
                                    <h4 class="mb-0">
                                        <?php echo e(number_format($total_salaries, 2)); ?>

                                        جنية</h4>
                                </div>
                                <div class="flex-fill text-right">
                                    <span class="sparkline inlinebar"><canvas width="40" height="32"
                                            style="display: inline-block; width: 40px; height: 32px; vertical-align: top;"></canvas></span>
                                </div>
                            </div>
                        </div> <!-- .card-body -->
                    </div> <!-- .card -->
                </div>
            </div>
            <div class="col-12">
                <div class="row align-items-center my-3">
                    <div class="col">
                        <h2 class="page-title">اضافة موظف</h2>
                    </div>
                </div>
                <form action="<?php echo e(route('dashboard.employee.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="text" value="<?php echo e(old('name')); ?>" name="name" class="form-control"
                            placeholder="اسم الموظف">
                        <input type="text" name="salary" value="<?php echo e(old('salary')); ?>" class="form-control"
                            placeholder="الراتب (جنية)">
                        <input type="text" name="work_days" value="<?php echo e(old('work_days')); ?>" class="form-control"
                            placeholder="عدد ايام العمل / الاسبوع">
                        <input type="text" name="work_hours" value="<?php echo e(old('work_hours')); ?>" class="form-control"
                            placeholder="عدد ساعات العمل / اليوم">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">اضافة</button>
                        </div>
                    </div>
                </form>
                <div class="row align-items-center my-3">
                    <div class="col">
                        <h2 class="page-title">الموظفيين</h2>
                    </div>
                </div>
                <div class="row my-4">
                    <!-- Small table -->
                    <div class="col-md-12">
                        <div class="card shadow">
                            <div class="card-body">
                                <!-- table -->
                                <table class="table datatables" id="dataTable-1">
                                    <thead>
                                        <tr>
                                            <th>الاسم</th>
                                            <th>الراتب</th>
                                            <th>عدد ايام العمل / الاسبوع</th>
                                            <th>عدد ساعات العمل / اليوم</th>
                                            <th class="w-100 p-0">تاريخ البداية</th>
                                            <th>حذف</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <span><?php echo e($employee->name); ?></span>
                                                    <div class="card-body">
                                                        <form id="employee_<?php echo e($employee->id); ?>" class="form-inline"
                                                            method="POST"
                                                            action="<?php echo e(route('dashboard.employee.update', ['employee' => $employee->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <input name="name" type="text"
                                                                class="form-control mb-2 mr-sm-2" placeholder="الاسم"
                                                                value="<?php echo e($employee->name); ?>">
                                                            <button for="employee_<?php echo e($employee->id); ?>" type="submit"
                                                                class="btn btn-sm btn-warning mb-2">تعديل</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span><?php echo e(number_format($employee->salary, 2)); ?></span>
                                                    <div class="card-body">
                                                        <form id="employee_salary_<?php echo e($employee->id); ?>" class="form-inline"
                                                            method="POST"
                                                            action="<?php echo e(route('dashboard.employee.update', ['employee' => $employee->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <input name="salary" type="text"
                                                                class="form-control mb-2 mr-sm-2" placeholder="الراتب"
                                                                value="<?php echo e($employee->salary); ?>">
                                                            <button for="employee_salary_<?php echo e($employee->id); ?>"
                                                                type="submit"
                                                                class="btn btn-sm btn-warning mb-2">تعديل</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span><?php echo e($employee->work_days); ?></span>
                                                    <div class="card-body">
                                                        <form id="employee_work_days_<?php echo e($employee->id); ?>"
                                                            class="form-inline" method="POST"
                                                            action="<?php echo e(route('dashboard.employee.update', ['employee' => $employee->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <input name="work_days" type="text"
                                                                class="form-control mb-2 mr-sm-2"
                                                                placeholder="عدد ايام العمل / الاسبوع"
                                                                value="<?php echo e($employee->work_days); ?>">
                                                            <button for="employee_work_days_<?php echo e($employee->id); ?>"
                                                                type="submit"
                                                                class="btn btn-sm btn-warning mb-2">تعديل</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span><?php echo e($employee->work_hours); ?></span>
                                                    <div class="card-body">
                                                        <form id="employee_work_hours_<?php echo e($employee->id); ?>"
                                                            class="form-inline" method="POST"
                                                            action="<?php echo e(route('dashboard.employee.update', ['employee' => $employee->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <input name="work_hours" type="text"
                                                                class="form-control mb-2 mr-sm-2"
                                                                placeholder="عدد ساعات العمل / اليوم"
                                                                value="<?php echo e($employee->work_hours); ?>">
                                                            <button for="employee_work_hours_<?php echo e($employee->id); ?>"
                                                                type="submit"
                                                                class="btn btn-sm btn-warning mb-2">تعديل</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <td class="w-100 p-0"><?php echo e($employee->created_at->format('Y-m-d')); ?></td>
                                                <td>
                                                    <form method="post"
                                                        action="<?php echo e(route('dashboard.employee.destroy', ['employee' => $employee->id])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit"
                                                            class="btn btn-sm btn-danger mb-2">حذف</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> <!-- simple table -->
                </div> <!-- end section -->
            </div> <!-- .col-12 -->
        </div> <!-- .row -->
    </div> <!-- .container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src='<?php echo e(asset('dashboard/js/jquery.dataTables.min.js')); ?>'></script>
    <script src='<?php echo e(asset('dashboard/js/dataTables.bootstrap4.min.js')); ?>'></script>

    <script>
        $('#dataTable-1').DataTable({
            autoWidth: true,
            order: []
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\desktop-apps\test\resources\views/dashboard/employee/index.blade.php ENDPATH**/ ?>