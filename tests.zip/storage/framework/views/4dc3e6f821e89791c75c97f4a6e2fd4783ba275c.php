<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'الشركاء'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="row col-12">
                <div class="col-md-6 col-xl-4 mb-4">
                    <div class="card shadow mb-4">
                        <div class="card-header">
                            <span class="card-title">رأس المال</span>
                        </div>
                        <div class="card-body my-n1">
                            <div class="d-flex">
                                <div class="flex-fill">
                                    <h4 class="mb-0"><?php echo e(number_format($partners->sum('capital'), 2)); ?> جنية</h4>
                                </div>
                                <div class="flex-fill text-right">
                                    <span class="sparkline inlinebar"><canvas width="40" height="32"
                                            style="display: inline-block; width: 40px; height: 32px; vertical-align: top;"></canvas></span>
                                </div>
                            </div>
                        </div> <!-- .card-body -->
                    </div> <!-- .card -->
                </div>
                <div class="col-md-6 col-xl-4 mb-4">
                    <div class="card shadow mb-4">
                        <div class="card-header">
                            <span class="card-title">الارباح</span>
                        </div>
                        <div class="card-body my-n1">
                            <div class="d-flex">
                                <div class="flex-fill">
                                    <h4 class="mb-0"><?php echo e(number_format($partners->sum('profits'), 2)); ?> جنية</h4>
                                </div>
                                <div class="flex-fill text-right">
                                    <span class="sparkline inlinebar"><canvas width="40" height="32"
                                            style="display: inline-block; width: 40px; height: 32px; vertical-align: top;"></canvas></span>
                                </div>
                            </div>
                        </div> <!-- .card-body -->
                    </div> <!-- .card -->
                </div>
                <div class="col-md-6 col-xl-4 mb-4">
                    <div class="card shadow mb-4">
                        <div class="card-header">
                            <span class="card-title">عدد الشركاء</span>
                        </div>
                        <div class="card-body my-n1">
                            <div class="d-flex">
                                <div class="flex-fill">
                                    <h4 class="mb-0"><?php echo e(count($partners)); ?></h4>
                                </div>
                                <div class="flex-fill text-right">
                                    <span class="sparkline inlinebar"><canvas width="40" height="32"
                                            style="display: inline-block; width: 40px; height: 32px; vertical-align: top;"></canvas></span>
                                </div>
                            </div>
                        </div> <!-- .card-body -->
                    </div> <!-- .card -->
                </div>
            </div>
            <div class="col-12">
                <div class="row align-items-center my-3">
                    <div class="col">
                        <h2 class="page-title">اضافة شريك</h2>
                    </div>
                </div>
                <?php $__errorArgs = ['capital'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: red">* <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <form action="<?php echo e(route('dashboard.partner.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control"
                            placeholder="الاسم">
                        <input type="number" value="<?php echo e(old('capital')); ?>" name="capital" class="form-control"
                            placeholder="رأس المال (جنية)">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">اضافة</button>
                        </div>
                    </div>
                </form>
                <div class="row align-items-center my-3">
                    <div class="col">
                        <h2 class="page-title">اضافة رأس مال</h2>
                    </div>
                </div>
                <form action="<?php echo e(route('dashboard.partner.capital.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="number" value="<?php echo e(old('amount')); ?>" name="amount" class="form-control"
                            placeholder="رأس المال (جنية)">
                        <select name="partner_id" class="form-control">
                            <option value="all">الجميع</option>
                            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($partner->id); ?>"><?php echo e($partner->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">اضافة</button>
                        </div>
                    </div>
                </form>
                <div class="row align-items-center my-3">
                    <div class="col">
                        <h2 class="page-title">الشركاء</h2>
                        <form method="post"
                            action="<?php echo e(route('dashboard.partner.payProfits.store', ['payall' => 1, 'amount' => $partners->sum('profits')])); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn btn-info mb-2">صرف
                                الارباح</button>
                        </form>
                    </div>
                </div>
                <div class="row my-4">
                    <!-- Small table -->
                    <div class="col-md-12">
                        <div class="card shadow">
                            <div class="card-body">
                                <!-- table -->
                                <table class="table datatables" id="dataTable-1">
                                    <thead>
                                        <tr>
                                            <th>الاسم</th>
                                            <th>رأس المال</th>
                                            <th>النسبة</th>
                                            <th>الارباح</th>
                                            <th>حذف</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <span><?php echo e($partner->name); ?></span>
                                                    <div class="card-body">
                                                        <form id="partner_name_<?php echo e($partner->id); ?>" class="form-inline"
                                                            method="POST"
                                                            action="<?php echo e(route('dashboard.partner.update', ['partner' => $partner->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <input name="name" type="text"
                                                                class="form-control mb-2 mr-sm-2" placeholder="الاسم"
                                                                value="<?php echo e($partner->name); ?>">
                                                            <button for="partner_name_<?php echo e($partner->id); ?>" type="submit"
                                                                class="btn btn-sm btn-warning mb-2">تعديل</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo e(number_format($partner->capital, 2)); ?> جنية
                                                </td>
                                                <td><?php echo e($partner->ratio()); ?> %</td>
                                                <td><?php echo e(number_format($partner->profits, 2)); ?> جنية</td>
                                                <td>
                                                    <form method="post"
                                                        action="<?php echo e(route('dashboard.partner.destroy', ['partner' => $partner->id])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit"
                                                            class="btn btn-sm btn-danger mb-2">حذف</button>
                                                    </form>
                                                    <form method="post"
                                                        action="<?php echo e(route('dashboard.partner.payProfits.store', ['partner_id' => $partner->id, 'payall' => 0, 'amount' => $partner->profits])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-sm btn-info mb-2">صرف
                                                            الارباح</button>
                                                    </form>
                                                    <a
                                                        href="<?php echo e(route('dashboard.partner.show', ['partner' => $partner->id])); ?>"><button
                                                            class="btn btn-sm btn-warning">سجل الارباح</button></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> <!-- simple table -->
                </div> <!-- end section -->
            </div> <!-- .col-12 -->
        </div> <!-- .row -->
    </div> <!-- .container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src='<?php echo e(asset('dashboard/js/jquery.dataTables.min.js')); ?>'></script>
    <script src='<?php echo e(asset('dashboard/js/dataTables.bootstrap4.min.js')); ?>'></script>

    <script>
        $('#dataTable-1').DataTable({
            autoWidth: true,
            order: []
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\desktop-apps\test\resources\views/dashboard/partner/index.blade.php ENDPATH**/ ?>